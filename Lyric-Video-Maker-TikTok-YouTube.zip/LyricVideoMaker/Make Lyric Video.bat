@echo off
setlocal EnableExtensions
title Lyric Video Maker
cd /d "%~dp0"

set "FFMPEG_DIR=D:\2 - Programmes\FFmpeg\FFmpeg\bin"

echo ============================================
echo   Lyric Video Maker  (TikTok / YouTube H.264)
echo ============================================
echo.

if not exist "%FFMPEG_DIR%\ffmpeg.exe" goto :ffmpeg_fallback
set "PATH=%FFMPEG_DIR%;%PATH%"
echo [ok] ffmpeg: %FFMPEG_DIR%\ffmpeg.exe
goto :ffmpeg_done

:ffmpeg_fallback
echo [!] ffmpeg.exe not found in "%FFMPEG_DIR%"
echo     Edit FFMPEG_DIR at the top of this .bat file, or add ffmpeg to PATH.
where ffmpeg >nul 2>nul
if errorlevel 1 (
    echo [x] ffmpeg is not on PATH either.
    pause
    exit /b 1
)
echo [ok] using ffmpeg from PATH

:ffmpeg_done

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
    echo [x] Python 3 is not installed.
    echo     Get it from https://www.python.org/downloads/ and tick "Add python.exe to PATH".
    pause
    exit /b 1
)
echo [ok] python: %PY%

echo.
echo Installing / checking Python packages...
%PY% -m pip install --disable-pip-version-check --quiet --upgrade -r requirements.txt
if errorlevel 1 (
    echo [x] pip install failed. Check your internet connection and try again.
    pause
    exit /b 1
)
echo [ok] packages ready
echo.

echo Choose platform:
echo   1 for TikTok, Reels or Shorts: 1080x1920 (9:16 vertical)
echo   2 for YouTube: 1920x1080 (16:9 widescreen)
echo.
choice /c 12 /n /m "Choose 1 or 2: "
if errorlevel 2 (
    set "FORMAT=youtube"
    set "SIZE=1920x1080"
) else (
    set "FORMAT=tiktok"
    set "SIZE=1080x1920"
)
echo [ok] %FORMAT% %SIZE%
echo.

echo Choose lyric style:
echo   1 for Kinetic: big bold scenes, words slam in (uses SRT style tags)
echo   2 for Karaoke Glow: full lines, each word lights up as it is sung
echo   3 for Cinematic: wide letters blur in, film grain, letterbox bars
echo.
choice /c 123 /n /m "Choose 1, 2 or 3: "
set "STYLE_N=%errorlevel%"
set "STYLE=kinetic"
if "%STYLE_N%"=="2" set "STYLE=karaoke"
if "%STYLE_N%"=="3" set "STYLE=cinema"
echo [ok] style: %STYLE%
echo.

echo Choose quality:
echo   1 = 60 fps, 20 Mbps  (best)
echo   2 = 30 fps, 12 Mbps
echo   3 = Quick preview, half size, 30 fps  (fast test)
echo.
choice /c 123 /n /m "Press 1, 2 or 3: "
set "MODE=%errorlevel%"
if "%MODE%"=="3" (
    set "RENDER_ARGS=--format %FORMAT% --preview"
    echo [ok] Quick preview
) else if "%MODE%"=="2" (
    set "RENDER_ARGS=--format %FORMAT% --fps 30"
    echo [ok] 30 fps
) else (
    set "RENDER_ARGS=--format %FORMAT% --fps 60"
    echo [ok] 60 fps
)

echo.
echo A window will open: choose the MP3 first, then the SRT.
echo.
%PY% lyric_video.py --ffmpeg "%FFMPEG_DIR%" %RENDER_ARGS% --style %STYLE% %*
if errorlevel 1 (
    echo.
    echo [x] Render failed. See the message above.
) else (
    echo.
    echo [ok] Video saved next to your MP3.
)
echo.
pause

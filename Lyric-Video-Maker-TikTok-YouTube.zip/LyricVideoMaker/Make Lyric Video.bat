@echo off
setlocal EnableExtensions
title Lyric Video Maker
cd /d "%~dp0"

set "FFMPEG_DIR=D:\2 - Programmes\FFmpeg\FFmpeg\bin"

echo ============================================
echo   Lyric Video Maker  (TikTok / YouTube H.264)
echo ============================================
echo.

if not exist "%FFMPEG_DIR%\ffmpeg.exe" goto :ffmpeg_fallback
set "PATH=%FFMPEG_DIR%;%PATH%"
echo [ok] ffmpeg: %FFMPEG_DIR%\ffmpeg.exe
goto :ffmpeg_done

:ffmpeg_fallback
echo [!] ffmpeg.exe not found in "%FFMPEG_DIR%"
echo     Edit FFMPEG_DIR at the top of this .bat file, or add ffmpeg to PATH.
where ffmpeg >nul 2>nul
if errorlevel 1 (
    echo [x] ffmpeg is not on PATH either.
    pause
    exit /b 1
)
echo [ok] using ffmpeg from PATH

:ffmpeg_done

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
    echo [x] Python 3 is not installed.
    echo     Get it from https://www.python.org/downloads/ and tick "Add python.exe to PATH".
    pause
    exit /b 1
)
echo [ok] python: %PY%

echo.
echo Installing / checking Python packages...
%PY% -m pip install --disable-pip-version-check --quiet --upgrade -r requirements.txt
if errorlevel 1 (
    echo [x] pip install failed. Check your internet connection and try again.
    pause
    exit /b 1
)
echo [ok] packages ready
echo.

echo Choose platform:
echo   1 for TikTok, Reels or Shorts: 1080x1920 (9:16 vertical)
echo   2 for YouTube: 1920x1080 (16:9 widescreen)
echo.
choice /c 12 /n /m "Choose 1 or 2: "
if errorlevel 2 (
    set "FORMAT=youtube"
    set "SIZE=1920x1080"
) else (
    set "FORMAT=tiktok"
    set "SIZE=1080x1920"
)
echo [ok] %FORMAT% %SIZE%
echo.

set "RENDER_ARGS=--format %FORMAT% --fps 120"
echo [ok] 120 fps, 25 Mbps

echo.
echo A window will open: choose the MP3 first, then the SRT.
echo.
set "LYRIC_OUT_FILE=%TEMP%\lyric_video_last.txt"
if exist "%LYRIC_OUT_FILE%" del "%LYRIC_OUT_FILE%"
%PY% lyric_video.py --ffmpeg "%FFMPEG_DIR%" %RENDER_ARGS% %*
if errorlevel 1 (
    echo.
    echo [x] Render failed. See the message above.
    pause
    exit /b 1
)
if not exist "%LYRIC_OUT_FILE%" (
    echo [x] Could not find the finished video.
    pause
    exit /b 1
)
set /p "LYRIC_MP4=" < "%LYRIC_OUT_FILE%"
echo.
echo [ok] Lyric video: "%LYRIC_MP4%"

rem ---- TikTok quality pass on the finished MP4 ----
set "REPO=C:\Users\wizve\Desktop\tiktok-quality-main"
if not exist "%REPO%\src\tiktok_quality\__main__.py" (
    echo [!] tiktok-quality not found at "%REPO%", skipping quality pass.
    goto :finish
)
if not exist "%FFMPEG_DIR%\ffprobe.exe" (
    echo [!] ffprobe.exe not found in "%FFMPEG_DIR%", skipping quality pass.
    goto :finish
)
set "PYTHONPATH=%REPO%\src;%PYTHONPATH%"
for %%F in ("%LYRIC_MP4%") do set "OUTPUT=%%~dpnF - hight tiktik.mp4"
echo.
echo Running TikTok quality pass...
echo Input:  "%LYRIC_MP4%"
echo Output: "%OUTPUT%"
echo.
%PY% -m tiktok_quality "%LYRIC_MP4%" "%OUTPUT%"
if errorlevel 1 (
    echo.
    echo [!] Quality pass failed. The lyric video is still saved:
    echo "%LYRIC_MP4%"
    goto :finish
)
if exist "%OUTPUT%" del "%LYRIC_MP4%"
echo.
echo [+] Finished. Output saved to:
echo "%OUTPUT%"

:finish
echo.
pause

LYRIC VIDEO MAKER  -  TikTok / YouTube lyric videos from MP3 + SRT
==================================================================

HOW TO RUN (Windows)
  1. Install Python 3 from https://www.python.org/downloads/
     (tick "Add python.exe to PATH" during setup).
  2. Double-click "Make Lyric Video.bat".
     - It installs the Python package it needs (Pillow) automatically.
     - It uses ffmpeg from:  D:\2 - Programmes\FFmpeg\FFmpeg\bin
       (to change it, edit the FFMPEG_DIR line at the top of the .bat)
  3. Choose 1 for TikTok, Reels or Shorts: 1080x1920 (9:16 vertical)
     or 2 for YouTube: 1920x1080 (16:9 widescreen).
  4. Choose your MP3, then your SRT.
  5. Type a color number and press Enter (just Enter = wine / pink).
  6. The video is always made at 120 fps, then run through the TikTok
     quality pass (C:\Users\wizve\Desktop\tiktok-quality-main).
     Only the final file is kept, next to your MP3, e.g.
       mysong-wine-tiktok-1080x1920-120fps - hight tiktik.mp4
     If the quality pass is missing or fails, the 120 fps video is kept.

COLORS
  wine, maroon, red, crimson, navy, royal, teal, forest, purple, noir,
  sunset, lime  - or type your own two hex colors (background, text).
  Command line:  python lyric_video.py --palette royal
                 python lyric_video.py --light "#E3FF73" --dark "#0B1B3F"

OUTPUT
  TikTok 1080x1920 or YouTube 1920x1080, H.264 High, 120 fps @ 25 Mbps,
  AAC 256 kbps 48 kHz stereo, faststart.

FILES
  lyric_video.py           the renderer
  Make Lyric Video.bat     double-click launcher
  requirements.txt         Python packages
  fonts\                   Anton, Poppins, Great Vibes (SIL Open Font License)
  example-simple.srt       short example showing every style tag
  example-good-reason.srt  full example timed to "Good Reason"

SRT STYLE TAGS  (put at the start of a subtitle, combine with commas)
  {small}          lowercase words that build up one by one
  {stack}          big bold lines that slide in one by one
  {giant}          one word stretched to fill the screen
  {script}         handwritten word that writes itself on  (or *stars*)
  {blank}          empty background
  {dark} {light}   background color for that subtitle
  {ghost=WORD}     outlined word drifting in the background
  {noghost}        no background word
  Example:  {stack,dark,ghost=REASON}

EXACT TIMING
  Put a time before a word, line or letters:  <00:00:02,420>GOOD
  Without it, words are spread across the subtitle automatically.

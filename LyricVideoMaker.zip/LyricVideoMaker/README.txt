LYRIC VIDEO MAKER  -  TikTok-ready kinetic typography from MP3 + SRT
=====================================================================

HOW TO RUN (Windows)
  1. Install Python 3 from https://www.python.org/downloads/
     (tick "Add python.exe to PATH" during setup).
  2. Double-click "Make Lyric Video.bat".
     - It installs the Python package it needs (Pillow) automatically.
     - It uses ffmpeg from:  D:\2 - Programmes\FFmpeg\FFmpeg\bin
       (to change it, edit the FFMPEG_DIR line at the top of the .bat)
  3. Type 30 or 60 for the frame rate (just press Enter for 60).
  4. Choose your MP3, then your SRT.
  5. The MP4 is saved next to your MP3, e.g.
       mysong-tiktok-1080x1920-60fps.mp4

OUTPUT
  1080x1920 (9:16), H.264 High, 60 fps @ 20 Mbps or 30 fps @ 12 Mbps,
  AAC 256 kbps 48 kHz stereo, faststart.

FILES
  lyric_video.py           the renderer
  Make Lyric Video.bat     double-click launcher
  requirements.txt         Python packages
  fonts\                   Anton, Poppins, Great Vibes (SIL Open Font License)
  example-simple.srt       short example showing every style
  example-good-reason.srt  full example timed to "Good Reason"

SRT STYLE TAGS  (put at the start of a subtitle's text, combine with commas)
  {small}          lowercase words that build up one by one
  {stack}          big bold lines that slide in one by one
  {giant}          one word stretched to fill the screen
  {script}         handwritten word that writes itself on  (or *stars*)
  {blank}          empty background
  {dark} {light}   background color for that subtitle
  {ghost=WORD}     outlined word drifting in the background
  {noghost}        no background word
  Example:  {stack,dark,ghost=REASON}

EXACT TIMING
  Put a time before a word, line or letters:  <00:00:02,420>GOOD
  Without it, words are spread across the subtitle automatically.

COLORS
  Default: taupe #B19886 and maroon #390001.
  Command line:  python lyric_video.py --light "#E3FF73" --dark "#0B1B3F"

@echo off
setlocal EnableExtensions
title Lyric Video Maker
cd /d "%~dp0"

set "FFMPEG_DIR=D:\2 - Programmes\FFmpeg\FFmpeg\bin"

echo ============================================
echo   Lyric Video Maker  (TikTok 1080x1920 H.264)
echo ============================================
echo.

if not exist "%FFMPEG_DIR%\ffmpeg.exe" goto :ffmpeg_fallback
set "PATH=%FFMPEG_DIR%;%PATH%"
echo [ok] ffmpeg: %FFMPEG_DIR%\ffmpeg.exe
goto :ffmpeg_done

:ffmpeg_fallback
echo [!] ffmpeg.exe not found in "%FFMPEG_DIR%"
echo     Edit FFMPEG_DIR at the top of this .bat file, or add ffmpeg to PATH.
where ffmpeg >nul 2>nul
if errorlevel 1 (
    echo [x] ffmpeg is not on PATH either.
    pause
    exit /b 1
)
echo [ok] using ffmpeg from PATH

:ffmpeg_done

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
    echo [x] Python 3 is not installed.
    echo     Get it from https://www.python.org/downloads/ and tick "Add python.exe to PATH".
    pause
    exit /b 1
)
echo [ok] python: %PY%

echo.
echo Installing / checking Python packages...
%PY% -m pip install --disable-pip-version-check --quiet --upgrade -r requirements.txt
if errorlevel 1 (
    echo [x] pip install failed. Check your internet connection and try again.
    pause
    exit /b 1
)
echo [ok] packages ready
echo.

set "FPS=60"
set /p "FPS=Frame rate - 30 or 60 [60]: "
if not "%FPS%"=="30" set "FPS=60"

echo.
echo A window will open: choose the MP3 first, then the SRT.
echo.
%PY% lyric_video.py --ffmpeg "%FFMPEG_DIR%" --fps %FPS% %*
if errorlevel 1 (
    echo.
    echo [x] Render failed. See the message above.
) else (
    echo.
    echo [ok] Video saved next to your MP3.
)
echo.
pause
